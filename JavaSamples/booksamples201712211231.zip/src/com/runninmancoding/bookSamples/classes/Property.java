package com.runninmancoding.bookSamples.classes;

import com.runninmancoding.bookSamples.classes.automobiles.Automobile;
import com.runninmancoding.bookSamples.classes.residences.House;

public class Property {
	public Automobile auto = new Automobile();
	public House house = new House();

}
