package com.runninmancoding.bookSamples.classes.automobiles;

public class Automobile {
	public void publicMethod(){
		System.out.println("Publicly accessible method");
	}
	
	protected void protectedMethod(){
		System.out.println("Protected method");
	}
}
