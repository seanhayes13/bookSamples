package com.runninmancoding.bookSamples.controlStatements;

public class WhileLoopExamples {
	public static void main(String[] args){
		int i = 0;
		do{
			//print a message
			System.out.println(i);
			i++;
		} while(i < 5);
	}
}
