package com.runninmancoding.bookSamples.strings;

public class StringExamples {
	public static void main(String[] args){
		String testString = "the quick brown fox jumped over the lazy dog";
		String[] words = testString.split(" ");
		System.out.println(words[0]);
		System.out.println(words[words.length-1]);
	}

}
